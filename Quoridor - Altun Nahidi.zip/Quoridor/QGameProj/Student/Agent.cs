﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;

class Agent : BaseAgent
{
    [STAThread]
    static void Main()
    {
        Program.Start(new Agent());
    }

    public Agent() { }

    public override Drag SökNästaDrag(SpelBräde bräde)
    {     
        Spelare jag = bräde.spelare[0]; // AI-controlled player
        Spelare motståndare = bräde.spelare[1]; // Opponent

        // 1. Calculate the shortest path for the AI to the goal
        List<Point> myPath = FindShortestPath(bräde, jag.position, new Point(0, 8)); // Goal: Reach the top row (Y = 0)

        // 2. Calculate the shortest path for the opponent to their goal
        List<Point> opponentPath = FindShortestPath(bräde, motståndare.position, new Point(8, 0)); // Opponent goal: Reach the bottom row (Y = 8)


        // Decide whether to move or place a wall
        Drag drag = new Drag();
        if (myPath.Count <= opponentPath.Count || jag.antalVäggar <= 0)
        {
            // If our path is shorter or equal, move forward along our path
            drag.typ = Typ.Flytta;
            drag.point = myPath[1]; // Move to the next step in the path
        }
        else
        {
            // Place a wall to hinder the opponent if it's advantageous
            drag = PlaceWallToBlockOpponent(bräde, motståndare, opponentPath, myPath);
        }

        return drag;
    }

    private List<Point> FindShortestPath(SpelBräde bräde, Point start, Point goal)
    {
        // Breadth-First Search (BFS) for shortest pathfinding
        Queue<Point> queue = new Queue<Point>();
        Dictionary<Point, Point?> cameFrom = new Dictionary<Point, Point?>();

        queue.Enqueue(start);
        cameFrom[start] = null;

        while (queue.Count > 0)
        {
            Point current = queue.Dequeue();

            if (current == goal) break;

            foreach (Point neighbor in GetNeighbors(bräde, current))
            {
                if (!cameFrom.ContainsKey(neighbor))
                {
                    queue.Enqueue(neighbor);
                    cameFrom[neighbor] = current;
                }
            }
        }

        // Reconstruct path
        List<Point> path = new List<Point>();
        Point? step = goal;
        while (step != null && cameFrom.ContainsKey(step.Value))
        {
            path.Add(step.Value);
            step = cameFrom[step.Value];
        }
        path.Reverse();

        return path;
    }

    private IEnumerable<Point> GetNeighbors(SpelBräde bräde, Point pos)
    {
        // Get valid neighboring points based on the board state and walls
        List<Point> neighbors = new List<Point>();
        Point[] directions = { new Point(0, 1), new Point(1, 0), new Point(0, -1), new Point(-1, 0) };

        foreach (Point dir in directions)
        {
            Point neighbor = new Point(pos.X + dir.X, pos.Y + dir.Y);
            if (IsMoveValid(bräde, pos, neighbor))
            {
                neighbors.Add(neighbor);
            }
        }

        return neighbors;
    }

    private bool HasWallBetween(SpelBräde bräde, Point from, Point to)
    {
        // Checks if there is a wall between 'from' and 'to' using the SpelBräde wall arrays
        if (from.X == to.X)
        {
            // Moving vertically
            int yMin = Math.Min(from.Y, to.Y);
            return bräde.horisontellaVäggar[from.X, yMin];
        }
        else if (from.Y == to.Y)
        {
            // Moving horizontally
            int xMin = Math.Min(from.X, to.X);
            return bräde.vertikalaVäggar[xMin, from.Y];
        }
        return false;
    }

    private bool CanPlaceWall(SpelBräde bräde, Point pos1, Point pos2, Typ typ)
    {
        if (typ == Typ.Horisontell)
        {
            int x = pos1.X;
            int yMin = Math.Min(pos1.Y, pos2.Y) - 1;

            // Ensure that both segments of the horizontal wall are free
            if (yMin >= 0 && yMin < 8 && x >= 0 && x < 8)
            {
                // Check both parts of the horizontal wall
                return !bräde.horisontellaVäggar[x, yMin] && !bräde.horisontellaVäggar[x + 1, yMin];
            }
        }
        else if (typ == Typ.Vertikal)
        {
            int y = pos1.Y;
            int xMin = Math.Min(pos1.X, pos2.X);

            // Adjust the check to ensure it's within valid bounds
            if (xMin >= 0 && xMin < 8 && y >= 0 && y <= 8)
            {
                // Ensure that we don't access out-of-bounds when checking y + 1
                if (y < 8)
                {
                    return !bräde.vertikalaVäggar[xMin, y] && !bräde.vertikalaVäggar[xMin, y + 1];
                }
                else
                {
                    // When y == 8, only check the current position as there is no y + 1
                    return !bräde.vertikalaVäggar[xMin, y];
                }
            }
        }

        return false;
    }

    private bool IsMoveValid(SpelBräde bräde, Point from, Point to)
    {
        // Check if 'to' is within bounds, not occupied, and not blocked by a wall
        return to.X >= 0 && to.X < 9 && to.Y >= 0 && to.Y < 9 && !HasWallBetween(bräde, from, to);
    }

    private Drag PlaceWallToBlockOpponent(SpelBräde bräde, Spelare opponent, List<Point> opponentPath, List<Point> myPath)
    {
        // Strategy: Place a wall closer to the opponent's current position along their path
        Drag drag = new Drag();

        for (int i = 0; i < opponentPath.Count - 1; i++)
        {
            Point pos1 = opponentPath[i];
            Point pos2 = opponentPath[i + 1];

            // Attempt to place a wall ahead of the opponent's position in their path
            if (CanPlaceWall(bräde, pos1, pos2, Typ.Horisontell))
            {
                // Simulate the wall placement
                if (SimulateWallAndCheckPaths(bräde, pos1, pos2, Typ.Horisontell))
                {
                    drag.typ = Typ.Horisontell;
                    drag.point = new Point(pos1.X, Math.Min(pos1.Y, pos2.Y) - 1);
                    break;
                }
            }
            else if (CanPlaceWall(bräde, pos1, pos2, Typ.Vertikal))
            {
                // Simulate the wall placement
                if (SimulateWallAndCheckPaths(bräde, pos1, pos2, Typ.Vertikal))
                {
                    drag.typ = Typ.Vertikal;
                    drag.point = new Point(Math.Min(pos1.X, pos2.X), Math.Min(pos1.Y, pos2.Y) - 1);
                    break;
                }
            }
            else
            {               
                drag.typ = Typ.Flytta;
                drag.point = myPath[1];
            }
                   
        }

        return drag;
    }

    private bool SimulateWallAndCheckPaths(SpelBräde bräde, Point pos1, Point pos2, Typ typ)
    {
        // Temporarily place a wall to simulate its effect
        bool wallPlaced = false;

        if (typ == Typ.Horisontell)
        {
            int x = pos1.X;
            int yMin = Math.Min(pos1.Y, pos2.Y) - 1;

            // Ensure yMin is within valid range for horizontal walls
            if (yMin >= 0 && yMin < 8 && x >= 0 && x < 8)
            {
                // Temporarily place the horizontal wall
                bräde.horisontellaVäggar[x, yMin] = true;
                bräde.horisontellaVäggar[x + 1, yMin] = true;
                wallPlaced = true;
            }
        }
        else if (typ == Typ.Vertikal)
        {
            int xMin = Math.Min(pos1.X, pos2.X);
            int y = pos1.Y;

            // Ensure y is within valid range for vertical walls
            if (xMin >= 0 && xMin < 8 && y >= 0 && y <= 8)
            {
                // Temporarily place the vertical wall
                bräde.vertikalaVäggar[xMin, y] = true;
                if (y < 8) // Check to ensure we don't go out of bounds
                {
                    bräde.vertikalaVäggar[xMin, y + 1] = true;
                }
                wallPlaced = true;
            }
        }

        // Check if both players have valid paths after placing the wall
        bool aiHasPath = FindShortestPath(bräde, bräde.spelare[0].position, new Point(0, 8)).Count > 0;
        bool opponentHasPath = FindShortestPath(bräde, bräde.spelare[1].position, new Point(8, 0)).Count > 0;

        // Undo the temporary wall placement
        if (wallPlaced)
        {
            if (typ == Typ.Horisontell)
            {
                int x = pos1.X;
                int yMin = Math.Min(pos1.Y, pos2.Y) - 1;
                bräde.horisontellaVäggar[x, yMin] = false;
                bräde.horisontellaVäggar[x + 1, yMin] = false;
            }
            else if (typ == Typ.Vertikal)
            {
                int xMin = Math.Min(pos1.X, pos2.X);
                int y = pos1.Y;
                bräde.vertikalaVäggar[xMin, y] = false;
                if (y < 8) // Only reset the next part if it was placed
                {
                    bräde.vertikalaVäggar[xMin, y + 1] = false;
                }
            }
        }

        // Only allow wall placement if both players have a path
        return aiHasPath && opponentHasPath;
    }



    public override Drag GörOmDrag(SpelBräde bräde, Drag drag)
    {
        // Re-calculate and attempt another move if the previous one was invalid
        System.Diagnostics.Debugger.Break(); // Breakpoint
        return SökNästaDrag(bräde);
    }
}
